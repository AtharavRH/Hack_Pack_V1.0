# frozen_string_literal: true

module WPScan
  module Model
    # Media
    class Media < InterestingFinding
    end
  end
end
