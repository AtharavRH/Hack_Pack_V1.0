# frozen_string_literal: true

module WPScan
  module Model
    # DB Export
    class DbExport < InterestingFinding
    end
  end
end
