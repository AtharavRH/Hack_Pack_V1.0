# frozen_string_literal: true

require_relative 'passwords/wp_login'
require_relative 'passwords/xml_rpc'
require_relative 'passwords/xml_rpc_multicall'
