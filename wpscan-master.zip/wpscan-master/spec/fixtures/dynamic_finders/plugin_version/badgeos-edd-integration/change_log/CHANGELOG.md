# Changelog

## 1.1
- Fix: Resolve conflict with BadgeOS Community add-on

## 1.0
- Initial