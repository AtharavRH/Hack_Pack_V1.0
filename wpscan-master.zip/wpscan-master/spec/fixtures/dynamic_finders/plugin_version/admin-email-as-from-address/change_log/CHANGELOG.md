Changelog
=========
#### 1.2 - November, 16 2016

**Improvements**

- Created General settings option fields to set From sender name and From sender email address. The filters aeafa_mail_from and aeafa_mail_from_name will still override these fields. Props Ramon Fincken. 
See also the included screenshot-2.png

#### 1.1 - November, 15 2016

**Improvements**

- Made the plugin extensible using filters. These filters are available: aeafa_mail_from and aeafa_mail_from_name 


#### 1.0 - September, 5 2016

- First release

