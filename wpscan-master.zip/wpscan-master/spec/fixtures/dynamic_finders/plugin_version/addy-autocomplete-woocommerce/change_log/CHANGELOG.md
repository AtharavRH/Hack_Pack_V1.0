# NZ Address Autocomplete for WooCommerce 2.1.2 #

* Call update events when an address is auto-completed 

# NZ Address Autocomplete for WooCommerce 2.1.1 #

* Added additional filters and configuration options

# NZ Address Autocomplete for WooCommerce 2.1.0.2 #

* Use Mailtown instead of City by default

# NZ Address Autocomplete for WooCommerce 2.1.0.2 #

* Fixed start-up bug

# NZ Address Autocomplete for WooCommerce 2.1.0 #

* Added the ability to filter PO Boxes addresses

# NZ Address Autocomplete for WooCommerce 2.0.0 #

* Addy, proudly made out of Auckland, New Zealand