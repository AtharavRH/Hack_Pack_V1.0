Sync this api key with the core server's Dockerfile (although you should really move those variables elsewhere), this helps authenticate requests as coming from the blinkie server.
