**Retire.js version: (`retire --version`):**

**node version: (`node --version`):**

**Type:**
Bug/Feature/Question

**Description:**

**Expected behaviour:**
