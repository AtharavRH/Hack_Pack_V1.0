<?php

namespace PHPGGC\GadgetChain;

abstract class PHPInfo extends \PHPGGC\GadgetChain
{
    public static $type = self::TYPE_INFO;
}