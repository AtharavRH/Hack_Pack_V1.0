<?php

namespace PHPGGC;

class Exception extends \Exception
{
    
}