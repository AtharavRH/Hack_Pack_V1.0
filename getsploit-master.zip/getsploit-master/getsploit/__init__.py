__all__ = ['getsploit']
__author__ = "Kir Ermakov <isox(at)vulners.com>"
__copyright__ = "Copyright 2018, Vulners"
__credits__ = ["Kir Ermakov",
               "Igor Bulatenko",
               "Ivan Elkin",
               "Gerome Fournier <jef(at)foutaise.org>",
               "JBFC"
               ]
__license__ = "LGPL"
__maintainer__ = "Kir Ermakov"
__email__ = "isox@vulners.com"
__status__ = "Release"
