Plugin template
===============

Printer template
===============

Encoder template
===============
