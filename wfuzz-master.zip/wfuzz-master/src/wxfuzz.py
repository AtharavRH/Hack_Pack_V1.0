#!/usr/bin/env python

from wfuzz.wfuzz import main_gui

if __name__ == "__main__":
    main_gui()
